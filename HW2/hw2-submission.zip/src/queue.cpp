#include "datastructure.hpp"
#include <string>
#include <sstream>

using namespace std;

void Queue::enqueue(int e)
{
    Node *ptr = new Node();
    Node *c = head;
    Node *p = head;

    //Initialize values of 
    ptr->val = e;
    ptr->next = NULL;

    if(head == NULL)
    {
        head = ptr;
    }
    else
    {
        while (c != NULL)
        {
            if(c->next == NULL)
            {
                break;
            }
            else{
                p = c;
                c = c->next;
            }
        }

        c->next = ptr;
        ptr->next = NULL;
    }
    
}

int Queue::dequeue()
{
    if(head == NULL){
        return 0;
    }

    else{
        Node *ptr = head;
        head = head->next;
        return ptr->val;
    }
}
Queue::Queue()
{
    head = NULL;
    s_size = 0;
}

void Queue::solution(const char *input_path, const char *output_path)
{
    ifstream iFile;
    iFile.open(input_path);
    ofstream oFile;
    oFile.open(output_path);

    if(iFile.fail())
    {
        cerr << "Error: File did not work" << endl;
        exit(1);
    }

    else{
        Queue q;
        string line;
        string flag;
        int temp;
        while(getline(iFile, line)){
            stringstream ss(line);
            ss >> flag;
            if(flag == "c"){
                //ignore
            }
            if(flag == "q"){
                //create an empty queue
            }
            if(flag == "e"){
                ss >> flag;
                temp = stoi(flag);
                q.enqueue(temp);
                q.s_size++;
                //enqueue a onto the existing queue. There will be only one 'a'
                //for each line starting with 'e'
            }
            if(flag == "d"){
                int cayuse;
                if(q.s_size > 0){
                    cayuse = q.dequeue();
                    oFile << cayuse << endl;
                    q.s_size--;
                }
                else{
                    //empty
                }
                //For line starting with d, dequeue the value and write into
                //output_file along with a new line.
            }
        }
    }
}
