#include "datastructure.hpp"
#include <string>
#include <sstream>

void Stack::push(int e)
{
    Node *ptr = new Node();
    ptr->val = e;
    ptr->next = head;
    head = ptr;
}

int Stack::pop()
{
    //Underflow case
    if(head == NULL){
        exit(1);
    }
    else{
        int e;
        Node *ptr = head;
        e = ptr->val;
        head = head->next;
        delete(ptr);
        return e;
    }
    
}

Stack::Stack()
{
   head = NULL;
   s_size = 0;
}

void Stack::solution(const char *input_path, const char *output_path)
{
    //Read in the file
    ifstream iFile;
    iFile.open(input_path);
    ofstream oFile;
    oFile.open(output_path);

    if(iFile.fail())
    {
        cerr << "Error: File did not work" << endl;
        exit(1);
    }

    else {
        Stack s;
        string line;
        string flag;
        int temp;
        while(getline(iFile, line)){
            stringstream ss(line);
            ss >> flag;
            if(flag == "s")
            {
                //initialize stack - ignore
            }
            else if (flag == "c")
            {
                //ignore
            }
            else if (flag == "u"){
                ss >> flag;
                temp = stoi(flag);
                s.push(temp);
            }
            else if (flag == "o")
            {
                int z;
                //cout << "Going in: " << endl; 
                z = s.pop();
                //cout << "Going out: " << endl;
                oFile << z << endl;
                
            }
        }
    }

}
