#include "datastructure.hpp"
#include <string>
#include <sstream>

using namespace std;

bool LinkedList::is_circular()
{
    return true;
}

string LinkedList::print()
{
    Node *c = head;
    string output;
    if(c == NULL){
        cout << "Empty linked list" << endl;
    }
    else{
        
        while(c){
            output.append(to_string(c->val));
            output.append(" ");
            c = c->next;
        }
        return output;
    }

    return output;
}

string LinkedList::print(int i, int j)
{
    //NEED TO CHANGE RETURN OUTPUT
    Node *c = head;
    int a = 0;
    string output;

    if(c == NULL){
        cout << "Empty linked list" << endl;
    }

    else{
        while (a < i){
            c = head->next;
            a += 1;
        }

        while(a < j){
            output.append(to_string(c->val));
            output.append(" ");
            a += 1;
            c = c->next;
        }

        return output;
    }

    return output;
}

void LinkedList::insert(int v)
{
    Node *ptr = new Node();
    ptr->val = v;
    ptr->next = head;
    head = ptr;
    //cout << "Value inserted: " << ptr->val << endl;
}

void LinkedList::del(int v)
{
    if(head == NULL)
    {
        cerr << "No values in linked list" << endl;
    }

    else
    {
        Node *c = head;
        Node *p = NULL;

        while(c != NULL)
        {
            if(c->val == v)
            {
                break;
            }

            else
            {
                p = c;
                c = c->next;
            }
        }

        //Node not found
        if(c == NULL)
        {
            cout << "Value could not be found" << endl;
        }

        else
        {
            if(head == c)
            {
                head = head->next;
            }

            else
            {
                p->next = c->next;
            }

        }
    }
}

void LinkedList::reverse()
{
    Node *trail;
    Node *curr;
    Node *n;

    trail = NULL;
    curr = head;

    while(curr != NULL)
    {
        n = curr->next;
        curr->next = trail;
        trail = curr;
        curr = n;
    }

    head = trail;
}

void LinkedList::link(int a, int b)
{
    if(head == NULL)
    {
        cerr << "LINK FAILED: No values in linked list" << endl;
    }

    else
    {
        //Search for A
        Node *c1 = head;
        Node *p1 = NULL;

        //Search for B
        Node *c2 = head;
        Node *p2 = NULL;

        while(c1 != NULL)
        {
            if(c1->val == a)
            {
                break;
            }

            else
            {
                p1 = c1;
                c1 = c1->next;
            }
        }

        //Node not found
        if(c1 == NULL)
        {
            cout << "LINKAGE FAILURE: 'A' could not be found" << endl;
        }

        else
        {
            while(c2 != NULL)
            {
                if(c2->val == b)
                {
                    break;
                }

                else
                {
                    p2 = c2;
                    c2 = c2->next;
                }
            }   

            if(c2 == NULL)
            {
                cout << "LINKAGE FAILURE: 'B' could not be found" << endl;
            }

            else
            {
                c2->next = c1;
            }
            
        }
    }
}

void LinkedList::create_new(int a, int b)
{
    if(head == NULL)
    {
        cerr << "No values in linked list" << endl;
    }

    else
    {
        Node *c = head;
        Node *p = NULL;
        Node *i = new Node();
        i->val = b;
        i->next = NULL;

        while(c != NULL)
        {
            if(c->val == a)
            {
                break;
            }

            else
            {
                p = c;
                c = c->next;
            }
        }

        //Node not found
        if(c == NULL)
        {
            cout << "Value could not be found" << endl;
        }

        else
        {
            i->next = c->next;
            c->next = i;
        }
    }
}

LinkedList::LinkedList(int v)
{
    head = NULL;
    Node *i = new Node();
    i->val = v;
    i->next = NULL;
    head = i;
}

void LinkedList::solution(const char *input_path, const char *output_path)
{
    ifstream iFile;
    iFile.open(input_path);
    ofstream oFile;
    oFile.open(output_path);

    if(iFile.fail())
    {
        cerr << "Error: File did not open" << endl;
        exit(1); 
    }

    else{
        int temp = 0;
        int temp2 = 0;
        string line;
        string flag;
        LinkedList *ll = NULL;
        bool quandt;
        while(getline(iFile, line)){
            
            stringstream ss(line);
            ss >> flag;
            if(flag == "c")
            {
                //do nothing
            }

            if(flag == "h")
            {
                ss >> flag;
                temp = stoi(flag);
                ll = new LinkedList(temp);
            }

            if(flag == "i")
            {   
                ss >> flag;
                temp = stoi(flag);
                ll->insert(temp);
                //'i a' 
                //Insert node with `node.val = a` into the front of the linked list.
            }

            if(flag == "d")
            {                
                ss >> flag;
                temp = stoi(flag);
                ll->del(temp);
                //'d a'
                //Delete `node.val = a` from the linked list.  
                //Ignore the command if such node doesn't exist.
            }

            if(flag == "r"){
                ll->reverse();
                //'r'
                //Reverse the existing linked list. Do not print
            }

            if(flag == "n"){
                ss >> flag;
                temp = stoi(flag);
                ss >> flag;
                temp2 = stoi(flag);
                ll->create_new(temp, temp2);
                //'n a b'
                //Create a new 'node_b' with node_b.val = b
                //Insert the new node after 'node_a' where node_a.val = a
            }

            if(flag == "l"){
                ss >> flag;
                temp = stoi (flag);
                ss >> flag;
                temp2 = stoi(flag);
                ll->link(temp, temp2);
                quandt = ll->is_circular();
                //'l a b'
                //Link 'node_a' with 'node_a.val = a' with 'node_b' with 'node_b.val = b'
                //Ignore the command if either node doesn't exist
            }

            if(flag == "p"){
                ss >> flag;
                if(flag == "p")
                {
                    oFile << ll->print();
                }
                else
                {
                    temp = stoi(flag);
                    ss >> flag;
                    temp2 = stoi(flag);
                    oFile << ll->print(temp, temp2);
                }
                //'p i j'
                //Print the linked list starting from [i, j), 0 indexed into the output file
                //If p has no arguments, then it will print the entire linked list starting from head. 
                //If the linked list is a circular linked list, then only print each item once.
                //Example listed in readme
            }

            if(flag == "o"){
                if(quandt == 1){
                    oFile << "1" << endl;
                }

                else{
                    oFile << "0" << endl;
                }
                
                //print 1 into outputfile if the linked list is a circular linked list, 0 otherwise
            }
        }

    }
}
