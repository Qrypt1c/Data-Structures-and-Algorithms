rm -f hw3-submission.zip
zip -r hw3-submission.zip . -x "*.git*" "*build*" "main.cpp" "*input*" "*expected*" "*autograder*" "*assets*" "*src/datastructure.hpp"
