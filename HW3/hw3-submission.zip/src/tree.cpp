#include "datastructure.hpp"
#include <sstream>
#include <queue>

Tree::Tree(int width){
    root = NULL;
    max_width = width;
}

int Tget_height(TreeNode* root){
    if (root == NULL){
        return 0;
    }
    
    else{
        TreeNode *temp = new TreeNode();
        queue<TreeNode*> hQ;
        hQ.push(root);

        int i = 0;
        int height = 0;
        int size;
        while(1){
            size = hQ.size();
            if (size == 0){
                break;
            }
            height++;
            
            while(size > 0){
                temp = hQ.front();
                hQ.pop();

                for(i = 0; i < temp->num_children; i++){
                    if(temp->children[i] != NULL){
                        hQ.push(temp->children[i]);
                    }
                }

                size--;
            }

        }
        return height;
    }

}

int Tree::get_height(){
    //cout << "Height is: " << Tget_height(root) << endl;
    return Tget_height(root);
}

string Tree::left_view(){
        TreeNode *l = new TreeNode();
        string output;
        queue<TreeNode*> lQ;
        if(root == NULL){
            output.append("");
            return output;
        }
        lQ.push(root);
        //cout << "Left view: " << endl;
        while(!lQ.empty()){
            l = lQ.front();
            output.append(to_string(l->key));
            output.append(" ");
            while(lQ.size() != 0){
                lQ.pop();
            }
            
            for(int i = 0; i < max_width; i++){
                if(l->children[i] != NULL){
                    lQ.push(l->children[i]);
                }
            }
        }
        return output;
        
}

string Tree::right_view(){
        TreeNode *r = new TreeNode();
        string outputR;
        queue<TreeNode*> rQ;
        if(root == NULL){
            outputR.append("");
            return outputR;
        }
        rQ.push(root);
        int i = 0;
        //cout << "Right view: " << endl;
        while(!rQ.empty()){
            r = rQ.back();
            outputR.append(to_string(r->key));
            outputR.append(" ");
            while(rQ.size() != 0){
                rQ.pop();
            }

            for(i = 0; i < max_width; i++){
                if(r->children[i] != NULL){
                    rQ.push(r->children[i]);
                }
            }
        }
        return outputR;
}

void Tree::insert_node(int key, int val){
    TreeNode* inode = new TreeNode();
    inode->key = key;
    inode->val = val;
    inode->num_children = 0;
    inode->children = new TreeNode* [max_width];
    for(int i = 0; i < max_width; i++){
        inode->children[i] = NULL;
    }

    if(root == NULL){
        root = inode;
        //cout << "Root is inserted" << endl;
    }

    else{
        TreeNode *temp = new TreeNode();
        queue<TreeNode*> aQ;
        aQ.push(root);
        int i = 0;
        while(!aQ.empty()){
            temp = aQ.front();
            aQ.pop();
            if(temp->num_children != max_width){
                for(int i = 0; i < max_width; i++){
                    if (temp->children[i] == NULL)
                    {
                        temp->children[i] = inode;
                        temp->num_children++;
                        break;
                    }
                }
                break;
            }

            for(i = 0; i < temp->num_children; i++){
                aQ.push(temp->children[i]);
            }

            //cout << "Node was full, retrying..." << endl;

        }

    }
}

void Tree::delete_node(int val){
    TreeNode* dnode = new TreeNode();
    TreeNode* child = new TreeNode();
    queue<TreeNode*> dQ;
    dQ.push(root);

    if (root->val == val){
        for(int i = 0; i < max_width; i++){
            root->children[i] = NULL;
        }
        root = NULL;

        return;
    }
    while(!dQ.empty()){
        dnode = dQ.front();
        dQ.pop();
        int tempest = dnode->num_children;
        for(int i = 0; i < tempest; i++){
            child = dnode->children[i];
            if(child->val == val){
                dnode->children[i] = NULL;
                dnode->num_children--;
            }
        }

        for(int i = 0; i < dnode->num_children; i++){
            if(dnode->children[i] != NULL){
                dQ.push(dnode->children[i]);
            }
            else{
                continue;
            }
        }
    }

}

void Tree::solution(const char *input_path, const char *output_path){
    ifstream iFile;
    iFile.open(input_path);
    ofstream oFile;
    oFile.open(output_path);

    if(iFile.fail())
    {
        cerr << "Error: File did not work" << endl;
        exit(1);
    }
 
    else{
        string line;
        string flag;
        int temp;
        int temp2;
        Tree* t = NULL;
        while(getline(iFile, line)){
            stringstream ss(line);
            ss >> flag;
            //Comment
            if(flag == "c"){
            }

            //Create empty tree
            if(flag == "t"){
                ss >> flag;
                temp = stoi(flag);
                t = new Tree(temp);
            }

            //Insert Node
            if(flag == "i"){
                ss >> flag;
                temp = stoi(flag);
                ss >> flag;
                temp2 = stoi(flag);
                t->insert_node(temp, temp2);
            }
            //Left View
            if(flag == "l"){
                oFile << t->left_view() << endl;
            }

            //Right View
            if(flag == "r"){
                oFile << t->right_view() << endl;
            }

            //Delete Node
            if(flag == "d"){
                ss >> flag;
                temp = stoi(flag);
                t->delete_node(temp);
            }

            if(flag == "h"){
                oFile << t->get_height() << endl;
            }

        }
    }
}
