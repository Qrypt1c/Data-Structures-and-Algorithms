#include "datastructure.hpp"
#include <sstream>
#include <queue>
#include <map>
#include <iterator>
#include <cmath>

BST::BST() : Tree(2){}

int BSTget_height(TreeNode* node){
    if (node == NULL){
        return 0;
    }

    else{
        int left = BSTget_height(node->children[0]);
        int right = BSTget_height(node->children[1]);

        if(left > right){
            return (left+1);
        }

        else{
            return (right+1);
        }
    }

}

class Storage{
    public:
        TreeNode* n;
        int distance;

        Storage(TreeNode* n, int distance){
            this->n = n;
            this->distance = distance;
        }
};

string BST::top_view(){
    string out;

    if(root == NULL){
        out.append("");
        return out;
    }

    else{
        map<int, int> dict;
        queue<Storage> store;

        store.push(Storage(root, 0));

        while(!store.empty()){
            Storage temp = store.front();
            store.pop();

            if(!dict.count(temp.distance))
            {
                dict.insert({temp.distance, temp.n->val});
            }

            if(temp.n->children[0] != NULL){
                store.push(Storage(temp.n->children[0], (temp.distance-1)));
            }
            
            if(temp.n->children[1] != NULL){
                store.push(Storage(temp.n->children[1], (temp.distance+1)));
            }
        }

        map<int, int>::iterator iter;
        for(iter = dict.begin(); iter != dict.end(); ++iter){
            out.append((to_string(iter->second)));
            out.append(" ");
        }
        out.append("\n");
        
    }

    return out;
}

void pB(TreeNode* root, int distance, int level, multimap<int, pair<int, int>> &dict){
    //dict.find(distance)->first = Horizontal Distance
    //dict.find(distance)->second.first = Value of Node
    //dict.find(distance)->second.second = Level of Node

    if (root == NULL){
        return;
    }

    else{
        //If the horizontal distance is not found
        if(!dict.count(distance)){
            dict.insert({distance, make_pair(root->val, level)});
        }
        //If current level is GREATER than node found in dictionary with the same horizontal distance
        else if(level > dict.find(distance)->second.second){
            dict.erase(distance);
            dict.insert({distance, make_pair(root->val, level)});
        }
        //If current level is the SAME as the node found in the dictionary with the same horizontal distance
        else if(level == dict.find(distance)->second.second){
            dict.insert({distance, make_pair(root->val, level)});
        }

        pB(root->children[0], (distance-1), (level+1), dict);
        pB(root->children[1], (distance+1), (level+1), dict);
    }
}

string BST::bottom_view(){
    string out;
    multimap<int, pair<int, int>> yote;
    pB(root, 0, 0, yote);
    
    for(auto &pair: yote){
        out.append(to_string(pair.second.first));
        out.append(" ");
    }
    out.append("\n");
    return out;
}

void inorderTraversal(TreeNode* node, vector<TreeNode*>& nodes){
    if (node == NULL){
        return;
    }

    inorderTraversal(node->children[0], nodes);
    nodes.push_back(node);
    inorderTraversal(node->children[1], nodes);
}

vector<TreeNode*> Inorder(TreeNode* node, vector<TreeNode*>& nodes){
    inorderTraversal(node, nodes);
    for(int i = 0; i < nodes.size(); i++){
        nodes.at(i)->children[0] = NULL;
        nodes.at(i)->children[1] = NULL;
    }
    return nodes;
}


TreeNode* base_case(vector<TreeNode*>& nodes){
    if (nodes.size() == 0){
        return NULL;
    }

    if (nodes.size() == 1){
        return nodes.at(0);
    }

    if(nodes.size() == 2){
        nodes.at(1)->children[0] = nodes.at(0);
        return nodes.at(1);
    }

    if(nodes.size() == 3){
        nodes.at(1)->children[0] = nodes.at(0);
        nodes.at(1)->children[1] = nodes.at(2);
        return nodes.at(1);
    }

    return NULL;
}

TreeNode* helper_balance(vector<TreeNode*>& nodes){
    int n = nodes.size();

    if(n < 4){
        return base_case(nodes);
    }

    int h = (floor(log2(n)) + 1);
    int n_left = pow(2, h-1) - 1;

    TreeNode* left = new TreeNode();
    vector<TreeNode*> leftNodes;
    for(int i = 0; i < n_left; i++){
        leftNodes.push_back(nodes.at(i));
    }

    left = helper_balance(leftNodes);

    TreeNode* right = new TreeNode();
    vector<TreeNode*> rightNodes;
    for(int i = n_left+1; i < nodes.size(); i++){
        rightNodes.push_back(nodes.at(i));
    }

    right = helper_balance(rightNodes);

    nodes.at(n_left)->children[0] = left;
    nodes.at(n_left)->children[1] = right;

    return nodes.at(n_left);
}

TreeNode* rBalance(TreeNode* node, vector<TreeNode*>& nodes){
    TreeNode* temp = new TreeNode();
    temp = nodes.at(0);
    return helper_balance(nodes);
}

void BST::rebalance(){
    vector<TreeNode*> nodes;
    Inorder(root, nodes);
    root = rBalance(root, nodes);
}


void BST::insert(int key, int val){
    //Create node
    TreeNode* inode = new TreeNode();
    
    inode->key = key;
    inode->val = val;
    inode->num_children = max_width;
    inode->children = new TreeNode* [max_width-1];
    inode->children[0] = NULL;
    inode->children[1] = NULL;

    //Insert
    if(root == NULL){
        root = inode;
        //cout << "Root is inserted" << endl;
    }

    else{
        TreeNode* temp = new TreeNode();
        temp = root;

        while(temp != NULL){
            if((inode->val < temp->val) && (temp->children[0] == NULL)){
                temp->children[0] = inode;
                //cout << "Value inserted to the left" << endl;
                break;
            }

            else if(inode->val < temp->val)
            {
                temp = temp->children[0];
            }

            else if((temp->children[1] == NULL) && (inode->val >= temp->val)){
                temp->children[1] = inode;
                //cout << "Value inserted to the right" << endl;
                break;
            }

            else{
                temp = temp->children[1];
            }
        }
    }

}

void BST::solution(const char *input_path, const char *output_path){
    ifstream iFile;
    iFile.open(input_path);
    ofstream oFile;
    oFile.open(output_path);

    if(iFile.fail())
    {
        cerr << "Error: File did not work" << endl;
        exit(1);
    }

    else{
        string out;
        string line;
        string flag;
        int temp;
        int temp2;
        BST* b = NULL;
        while(getline(iFile, line)){
            stringstream ss(line);
            ss >> flag;
            if(flag == "c"){
                //empty
            }

            if(flag == "e"){
                b = new BST();//Initialize BST
            }

            if(flag == "i"){
                ss >> flag;
                temp = stoi(flag);
                ss >> flag;
                temp2 = stoi(flag);
                b->insert(temp, temp2);//BST Insert
            }

            if(flag == "d"){
                ss >> flag;
                temp = stoi(flag);
                //BST Delete
            }

            if(flag == "t"){
                oFile << b->top_view();
            }

            if(flag == "b"){
                oFile << b->bottom_view();
            }

            if(flag == "r"){
                b->rebalance();//BST Rebalance   
            }

            if(flag == "h"){
                oFile << BSTget_height(b->root) << endl;

            }
        }

    }
}