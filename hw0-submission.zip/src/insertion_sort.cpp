
#include "utils.hpp"

void insertion_sort(IntSequence A)
{
    int x;
    int y;
    int key = 0;
    for (x = 1; x < A.length; x++)
    {
        key = A.array[x];
        y = x - 1;

        while (y >= 0 && A.array[y] > key)
        {
            A.array[y+1] = A.array[y];
            y = y - 1;
        }
        A.array[y+1] = key;
    } 
}

