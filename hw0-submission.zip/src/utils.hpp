/** vv Add additional declaration vv **/
#include <iostream>
#include <fstream>
#include <string>
/** ^^ Add additional declaration ^^ **/

using namespace std;
/** DO NOT CHANGE **/
struct IntSequence{
    int length;
    int *array;
};
void insertion_sort(IntSequence A);

/** DO NOT CHANGE **/
/** Add additional declaration below **/
