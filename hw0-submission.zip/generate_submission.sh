rm -f hw0-submission.zip
zip -r hw0-submission.zip . -x "*.git*" "*build*" 
